from django.apps import AppConfig


class FoodSiteConfig(AppConfig):
    name = 'food_site'
